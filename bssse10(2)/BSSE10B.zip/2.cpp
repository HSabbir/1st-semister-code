#include <iostream>

using namespace std;

int main (void)
{
	string s, faltu;
	int n;
	
	cin >> n;
	getline(cin, faltu);
	getline(cin,s);
	
	cout << n << " " << s << endl;
	
	return 0;
}
