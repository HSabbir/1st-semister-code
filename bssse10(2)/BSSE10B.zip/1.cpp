#include <iostream>

using namespace std;

int main (void)
{
	int n1;
	float n2;
	
	cin >> n1 >> n2;
	//cin >> n2;
	
	cout << n1 << " " << n2 << endl;
	
	/*
	cout << "This is our first output" << endl;
	*/
	
	return 0;
}
